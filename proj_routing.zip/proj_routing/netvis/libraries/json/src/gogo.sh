javac json/*.java
jar -cvf ../library/json.jar json/*.class
